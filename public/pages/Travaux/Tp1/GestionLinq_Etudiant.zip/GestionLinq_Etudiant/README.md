# TP LINQ - Architecture multi-tiers (.NET 8) - VERSION ÉTUDIANT

Solution complète : `GestionLinq.sln`

| Projet | Rôle |
|---|---|
| Gestion.Entities | Modèle (Produit, Categorie, Client, Commande, DTO) |
| Gestion.DAL | Accès aux données ADO.NET (SQL Server) + version Mémoire |
| Gestion.BLL | Requêtes LINQ À COMPLÉTER (15 exercices) |
| Gestion.UI.Console | Menu console |

## Lancer
- Visual Studio 2022 : ouvrir le .sln, projet de démarrage `Gestion.UI.Console`, F5, choisir 1 (Mémoire).
- Ligne de commande : `dotnet run --project src/Gestion.UI.Console -- --memory --all`
- Mode SQL Server (facultatif) : exécuter `Database/01_Creation_Base.sql`, choisir 2.
  Chaîne de connexion : variable d'environnement `GESTION_CS` (défaut : LocalDB).
- Sans accès NuGet : `dotnet build -p:UseSqlServer=false` (mode Mémoire uniquement).

Documents : `Docs/Enonce_TP_LINQ.docx` (énoncé du TP).
