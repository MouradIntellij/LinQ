/* =====================================================================
   TP LINQ multi-tiers - Script de création de la base GestionLinqDb
   SQL Server / LocalDB. Exécuter dans SSMS ou Azure Data Studio.
   ===================================================================== */
IF DB_ID('GestionLinqDb') IS NULL
    CREATE DATABASE GestionLinqDb;
GO
USE GestionLinqDb;
GO

DROP TABLE IF EXISTS Commande;
DROP TABLE IF EXISTS Produit;
DROP TABLE IF EXISTS Client;
DROP TABLE IF EXISTS Categorie;
GO

CREATE TABLE Categorie (
    Id  INT IDENTITY(1,1) PRIMARY KEY,
    Nom NVARCHAR(50) NOT NULL
);

CREATE TABLE Produit (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Nom         NVARCHAR(100)  NOT NULL,
    Prix        DECIMAL(10,2)  NOT NULL CHECK (Prix >= 0),
    Stock       INT            NOT NULL DEFAULT 0,
    CategorieId INT            NOT NULL REFERENCES Categorie(Id)
);

CREATE TABLE Client (
    Id    INT IDENTITY(1,1) PRIMARY KEY,
    Nom   NVARCHAR(100) NOT NULL,
    Ville NVARCHAR(50)  NOT NULL
);

CREATE TABLE Commande (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    ClientId     INT      NOT NULL REFERENCES Client(Id),
    ProduitId    INT      NOT NULL REFERENCES Produit(Id),
    Quantite     INT      NOT NULL CHECK (Quantite > 0),
    DateCommande DATE     NOT NULL
);
GO

INSERT INTO Categorie (Nom) VALUES (N'Informatique'), (N'Bureautique'), (N'Mobilier');

INSERT INTO Produit (Nom, Prix, Stock, CategorieId) VALUES
 (N'Ordinateur portable',  1200.00,   5, 1),
 (N'Souris sans fil',        25.50,  40, 1),
 (N'Clavier mécanique',      89.99,   0, 1),
 (N'Écran 27 pouces',       329.00,  12, 1),
 (N'Stylos (boîte de 50)',   12.00, 100, 2),
 (N'Cahier A4',               3.50, 250, 2),
 (N'Agrafeuse',              15.75,   0, 2),
 (N'Chaise ergonomique',    249.00,   8, 3),
 (N'Bureau réglable',       450.00,   3, 3),
 (N'Lampe de bureau',        39.90,  20, 3),
 (N'Casque audio',           79.00,  15, 1),
 (N'Classeur',                4.25,  60, 2);

INSERT INTO Client (Nom, Ville) VALUES
 (N'Alice Martin',    N'Paris'),
 (N'Karim Haddad',    N'Alger'),
 (N'Sophie Tremblay', N'Montréal'),
 (N'Youssef Idrissi', N'Casablanca'),
 (N'Lina Dupont',     N'Paris'),
 (N'Omar Diallo',     N'Dakar');

INSERT INTO Commande (ClientId, ProduitId, Quantite, DateCommande) VALUES
 (1, 1,  1, '2025-01-10'), (1, 2,  2, '2025-01-10'),
 (2, 4,  2, '2025-01-15'),
 (3, 9,  1, '2025-02-01'), (3, 8,  2, '2025-02-01'),
 (4, 6, 20, '2025-02-12'), (4, 5,  3, '2025-02-12'),
 (5, 11, 1, '2025-03-03'), (5, 10, 2, '2025-03-03'),
 (6, 12,10, '2025-03-20'),
 (1, 11, 2, '2025-04-05'),
 (2, 1,  1, '2025-04-18');
GO

SELECT 'Base GestionLinqDb prête' AS Message;
