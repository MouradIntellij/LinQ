using System.Data;
using System.Data.Common;
using Gestion.DAL.Interfaces;
using Gestion.Entities;

namespace Gestion.DAL.Sql;

public class SqlProduitDal : IProduitDal
{
    private const string SelectSql = "SELECT Id, Nom, Prix, Stock, CategorieId FROM Produit";
    private readonly DbConnectionFactory _db;

    public SqlProduitDal(DbConnectionFactory db) => _db = db;

    // Transforme la ligne courante du DataReader en objet Produit
    private static Produit Map(DbDataReader r) => new()
    {
        Id = r.GetInt32(r.GetOrdinal("Id")),
        Nom = r.GetString(r.GetOrdinal("Nom")),
        Prix = r.GetDecimal(r.GetOrdinal("Prix")),
        Stock = r.GetInt32(r.GetOrdinal("Stock")),
        CategorieId = r.GetInt32(r.GetOrdinal("CategorieId"))
    };

    // --- Mode connecté : Connection + Command + DataReader ---
    public List<Produit> GetAll() => _db.Query(SelectSql, Map);

    public Produit? GetById(int id)
    {
        using DbConnection cn = _db.CreateConnection();
        using DbCommand cmd = cn.CreateCommand();
        cmd.CommandText = SelectSql + " WHERE Id = @id";
        DbConnectionFactory.AddParameter(cmd, "@id", id);
        cn.Open();
        using DbDataReader reader = cmd.ExecuteReader();
        return reader.Read() ? Map(reader) : null;
    }

    public int Add(Produit produit)
    {
        using DbConnection cn = _db.CreateConnection();
        using DbCommand cmd = cn.CreateCommand();
        cmd.CommandText =
            "INSERT INTO Produit (Nom, Prix, Stock, CategorieId) VALUES (@nom, @prix, @stock, @cat); " +
            "SELECT CAST(SCOPE_IDENTITY() AS INT);";
        DbConnectionFactory.AddParameter(cmd, "@nom", produit.Nom);
        DbConnectionFactory.AddParameter(cmd, "@prix", produit.Prix);
        DbConnectionFactory.AddParameter(cmd, "@stock", produit.Stock);
        DbConnectionFactory.AddParameter(cmd, "@cat", produit.CategorieId);
        cn.Open();
        produit.Id = (int)cmd.ExecuteScalar()!;
        return produit.Id;
    }

    // --- Mode déconnecté : DataAdapter + DataTable ---
    public DataTable GetAllAsTable()
    {
        var table = new DataTable("Produit");
        using DbConnection cn = _db.CreateConnection();
        using DbCommand cmd = cn.CreateCommand();
        cmd.CommandText = SelectSql;
        using DbDataAdapter adapter = _db.CreateAdapter();
        adapter.SelectCommand = cmd;
        adapter.Fill(table);          // ouvre et ferme la connexion automatiquement
        return table;
    }
}
