using Gestion.Entities;

namespace Gestion.DAL;

/// <summary>
/// Jeu de données de départ. Il est identique à celui du script SQL (Database/01_Creation_Base.sql),
/// ce qui garantit les mêmes résultats en mode Mémoire et en mode SQL Server.
/// </summary>
public static class SeedData
{
    public static List<Categorie> Categories() => new()
    {
        new() { Id = 1, Nom = "Informatique" },
        new() { Id = 2, Nom = "Bureautique" },
        new() { Id = 3, Nom = "Mobilier" },
    };

    public static List<Produit> Produits() => new()
    {
        new() { Id = 1,  Nom = "Ordinateur portable",    Prix = 1200.00m, Stock = 5,   CategorieId = 1 },
        new() { Id = 2,  Nom = "Souris sans fil",        Prix = 25.50m,   Stock = 40,  CategorieId = 1 },
        new() { Id = 3,  Nom = "Clavier mécanique",      Prix = 89.99m,   Stock = 0,   CategorieId = 1 },
        new() { Id = 4,  Nom = "Écran 27 pouces",        Prix = 329.00m,  Stock = 12,  CategorieId = 1 },
        new() { Id = 5,  Nom = "Stylos (boîte de 50)",   Prix = 12.00m,   Stock = 100, CategorieId = 2 },
        new() { Id = 6,  Nom = "Cahier A4",              Prix = 3.50m,    Stock = 250, CategorieId = 2 },
        new() { Id = 7,  Nom = "Agrafeuse",              Prix = 15.75m,   Stock = 0,   CategorieId = 2 },
        new() { Id = 8,  Nom = "Chaise ergonomique",     Prix = 249.00m,  Stock = 8,   CategorieId = 3 },
        new() { Id = 9,  Nom = "Bureau réglable",        Prix = 450.00m,  Stock = 3,   CategorieId = 3 },
        new() { Id = 10, Nom = "Lampe de bureau",        Prix = 39.90m,   Stock = 20,  CategorieId = 3 },
        new() { Id = 11, Nom = "Casque audio",           Prix = 79.00m,   Stock = 15,  CategorieId = 1 },
        new() { Id = 12, Nom = "Classeur",               Prix = 4.25m,    Stock = 60,  CategorieId = 2 },
    };

    public static List<Client> Clients() => new()
    {
        new() { Id = 1, Nom = "Alice Martin",     Ville = "Paris" },
        new() { Id = 2, Nom = "Karim Haddad",     Ville = "Alger" },
        new() { Id = 3, Nom = "Sophie Tremblay",  Ville = "Montréal" },
        new() { Id = 4, Nom = "Youssef Idrissi",  Ville = "Casablanca" },
        new() { Id = 5, Nom = "Lina Dupont",      Ville = "Paris" },
        new() { Id = 6, Nom = "Omar Diallo",      Ville = "Dakar" },
    };

    public static List<Commande> Commandes() => new()
    {
        new() { Id = 1,  ClientId = 1, ProduitId = 1,  Quantite = 1,  DateCommande = new DateTime(2025, 1, 10) },
        new() { Id = 2,  ClientId = 1, ProduitId = 2,  Quantite = 2,  DateCommande = new DateTime(2025, 1, 10) },
        new() { Id = 3,  ClientId = 2, ProduitId = 4,  Quantite = 2,  DateCommande = new DateTime(2025, 1, 15) },
        new() { Id = 4,  ClientId = 3, ProduitId = 9,  Quantite = 1,  DateCommande = new DateTime(2025, 2, 1)  },
        new() { Id = 5,  ClientId = 3, ProduitId = 8,  Quantite = 2,  DateCommande = new DateTime(2025, 2, 1)  },
        new() { Id = 6,  ClientId = 4, ProduitId = 6,  Quantite = 20, DateCommande = new DateTime(2025, 2, 12) },
        new() { Id = 7,  ClientId = 4, ProduitId = 5,  Quantite = 3,  DateCommande = new DateTime(2025, 2, 12) },
        new() { Id = 8,  ClientId = 5, ProduitId = 11, Quantite = 1,  DateCommande = new DateTime(2025, 3, 3)  },
        new() { Id = 9,  ClientId = 5, ProduitId = 10, Quantite = 2,  DateCommande = new DateTime(2025, 3, 3)  },
        new() { Id = 10, ClientId = 6, ProduitId = 12, Quantite = 10, DateCommande = new DateTime(2025, 3, 20) },
        new() { Id = 11, ClientId = 1, ProduitId = 11, Quantite = 2,  DateCommande = new DateTime(2025, 4, 5)  },
        new() { Id = 12, ClientId = 2, ProduitId = 1,  Quantite = 1,  DateCommande = new DateTime(2025, 4, 18) },
    };
}
