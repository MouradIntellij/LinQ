using Gestion.DAL.Interfaces;
using Gestion.Entities;

namespace Gestion.DAL.Sql;

public class SqlCategorieDal : ICategorieDal
{
    private readonly DbConnectionFactory _db;
    public SqlCategorieDal(DbConnectionFactory db) => _db = db;

    public List<Categorie> GetAll() =>
        _db.Query("SELECT Id, Nom FROM Categorie",
                  r => new Categorie { Id = r.GetInt32(0), Nom = r.GetString(1) });
}

public class SqlClientDal : IClientDal
{
    private readonly DbConnectionFactory _db;
    public SqlClientDal(DbConnectionFactory db) => _db = db;

    public List<Client> GetAll() =>
        _db.Query("SELECT Id, Nom, Ville FROM Client",
                  r => new Client { Id = r.GetInt32(0), Nom = r.GetString(1), Ville = r.GetString(2) });
}

public class SqlCommandeDal : ICommandeDal
{
    private readonly DbConnectionFactory _db;
    public SqlCommandeDal(DbConnectionFactory db) => _db = db;

    public List<Commande> GetAll() =>
        _db.Query("SELECT Id, ClientId, ProduitId, Quantite, DateCommande FROM Commande",
                  r => new Commande
                  {
                      Id = r.GetInt32(0),
                      ClientId = r.GetInt32(1),
                      ProduitId = r.GetInt32(2),
                      Quantite = r.GetInt32(3),
                      DateCommande = r.GetDateTime(4)
                  });
}
