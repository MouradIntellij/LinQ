using System.Data;
using Gestion.Entities;

namespace Gestion.DAL.Memory;

/// <summary>Base de données "factice" en mémoire : permet de lancer le projet sans SQL Server.</summary>
public class MemoryStore
{
    public List<Categorie> Categories { get; } = SeedData.Categories();
    public List<Produit> Produits { get; } = SeedData.Produits();
    public List<Client> Clients { get; } = SeedData.Clients();
    public List<Commande> Commandes { get; } = SeedData.Commandes();
}

public class MemoryProduitDal : Interfaces.IProduitDal
{
    private readonly MemoryStore _store;
    public MemoryProduitDal(MemoryStore store) => _store = store;

    public List<Produit> GetAll() => _store.Produits.ToList();   // ToList() = copie, comme une vraie lecture BD

    public Produit? GetById(int id) => _store.Produits.FirstOrDefault(p => p.Id == id);

    public int Add(Produit produit)
    {
        produit.Id = _store.Produits.Count == 0 ? 1 : _store.Produits.Max(p => p.Id) + 1;
        _store.Produits.Add(produit);
        return produit.Id;
    }

    public DataTable GetAllAsTable()
    {
        var table = new DataTable("Produit");
        table.Columns.Add("Id", typeof(int));
        table.Columns.Add("Nom", typeof(string));
        table.Columns.Add("Prix", typeof(decimal));
        table.Columns.Add("Stock", typeof(int));
        table.Columns.Add("CategorieId", typeof(int));
        foreach (var p in _store.Produits)
            table.Rows.Add(p.Id, p.Nom, p.Prix, p.Stock, p.CategorieId);
        return table;
    }
}

public class MemoryCategorieDal : Interfaces.ICategorieDal
{
    private readonly MemoryStore _store;
    public MemoryCategorieDal(MemoryStore store) => _store = store;
    public List<Categorie> GetAll() => _store.Categories.ToList();
}

public class MemoryClientDal : Interfaces.IClientDal
{
    private readonly MemoryStore _store;
    public MemoryClientDal(MemoryStore store) => _store = store;
    public List<Client> GetAll() => _store.Clients.ToList();
}

public class MemoryCommandeDal : Interfaces.ICommandeDal
{
    private readonly MemoryStore _store;
    public MemoryCommandeDal(MemoryStore store) => _store = store;
    public List<Commande> GetAll() => _store.Commandes.ToList();
}
