using System.Data;
using Gestion.Entities;

namespace Gestion.DAL.Interfaces;

// La couche métier (BLL) ne connaît QUE ces interfaces.
// Elle ignore si les données viennent de SQL Server ou de la mémoire.

public interface IProduitDal
{
    List<Produit> GetAll();
    Produit? GetById(int id);
    int Add(Produit produit);

    /// <summary>Mode déconnecté : renvoie les produits dans un DataTable (pour LINQ to DataSet).</summary>
    DataTable GetAllAsTable();
}

public interface ICategorieDal
{
    List<Categorie> GetAll();
}

public interface IClientDal
{
    List<Client> GetAll();
}

public interface ICommandeDal
{
    List<Commande> GetAll();
}
