using System.Data;
using System.Data.Common;

namespace Gestion.DAL.Sql;

/// <summary>
/// Fabrique de connexions ADO.NET. Elle utilise les classes ABSTRAITES de System.Data.Common
/// (DbConnection, DbCommand, DbDataReader...) : le code de la DAL ne dépend donc pas
/// d'un fournisseur précis. On injecte SqlClientFactory.Instance pour SQL Server.
/// </summary>
public class DbConnectionFactory
{
    private readonly DbProviderFactory _factory;
    private readonly string _connectionString;

    public DbConnectionFactory(DbProviderFactory factory, string connectionString)
    {
        _factory = factory;
        _connectionString = connectionString;
    }

    public DbConnection CreateConnection()
    {
        var cn = _factory.CreateConnection() ?? throw new InvalidOperationException("Connexion impossible à créer.");
        cn.ConnectionString = _connectionString;
        return cn;
    }

    public DbDataAdapter CreateAdapter() =>
        _factory.CreateDataAdapter() ?? throw new InvalidOperationException("Adapter impossible à créer.");

    /// <summary>Ajoute un paramètre à une commande (protège contre l'injection SQL).</summary>
    public static void AddParameter(DbCommand cmd, string name, object value)
    {
        DbParameter p = cmd.CreateParameter();
        p.ParameterName = name;
        p.Value = value;
        cmd.Parameters.Add(p);
    }

    /// <summary>Mode CONNECTÉ : exécute un SELECT et transforme chaque ligne via la fonction "map".</summary>
    public List<T> Query<T>(string sql, Func<DbDataReader, T> map)
    {
        var result = new List<T>();
        using DbConnection cn = CreateConnection();
        using DbCommand cmd = cn.CreateCommand();
        cmd.CommandText = sql;
        cn.Open();
        using DbDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
            result.Add(map(reader));
        return result;
    }
}
