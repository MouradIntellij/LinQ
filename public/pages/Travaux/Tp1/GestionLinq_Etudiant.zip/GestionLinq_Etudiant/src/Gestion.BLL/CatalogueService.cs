using Gestion.DAL.Interfaces;
using Gestion.Entities;

namespace Gestion.BLL;

/// <summary>
/// TP ÉTUDIANT - Couche métier : complétez chaque méthode avec une requête LINQ.
/// Remplacez "throw new NotImplementedException();" par votre code.
/// Pour obtenir les données : _produitDal.GetAll() / _categorieDal.GetAll()
/// </summary>
public class CatalogueService
{
    private readonly IProduitDal _produitDal;
    private readonly ICategorieDal _categorieDal;

    public CatalogueService(IProduitDal produitDal, ICategorieDal categorieDal)
    {
        _produitDal = produitDal;
        _categorieDal = categorieDal;
    }

    // Exercice 1 : produits dont le stock est > 0.  (Where)
    public List<Produit> ProduitsEnStock() => throw new NotImplementedException();

    // Exercice 2 : produits dont le prix est > seuil, du plus cher au moins cher.  (Where + OrderByDescending)
    public List<Produit> ProduitsPlusChersQue(decimal seuil) => throw new NotImplementedException();

    // Exercice 3 : le nom de chaque produit en MAJUSCULES.  (Select)
    public List<string> NomsEnMajuscules() => throw new NotImplementedException();

    // Exercice 4 : (Nom, PrixHt, PrixTtc arrondi à 2 décimales) pour chaque produit.  (Select vers ProduitTtcDto)
    public List<ProduitTtcDto> ProduitsAvecPrixTtc(decimal tva = 0.20m) => throw new NotImplementedException();

    // Exercice 5 : le produit d'identifiant id, ou null s'il n'existe pas.  (FirstOrDefault)
    public Produit? TrouverParId(int id) => throw new NotImplementedException();

    // Exercice 6 : (a) existe-t-il un produit en rupture (stock = 0) ?  (b) tous les prix sont-ils > 0 ?  (Any / All)
    public bool ExisteProduitEnRupture() => throw new NotImplementedException();
    public bool TousLesPrixSontPositifs() => throw new NotImplementedException();

    // Exercice 7 : nombre de produits, nombre en stock, valeur du stock (somme prix*stock), prix moyen (2 décimales).
    //              (Count / Sum / Average)
    public StatistiquesStock CalculerStatistiques() => throw new NotImplementedException();

    // Exercice 8 : tri par CategorieId croissant puis par prix décroissant.  (OrderBy + ThenByDescending)
    public List<Produit> TrierParCategorieEtPrix() => throw new NotImplementedException();

    // Exercice 9 : par catégorie : nom, nombre de produits, prix moyen (2 décimales), triées par nom.  (GroupBy + Join)
    public List<CategorieStatDto> StatistiquesParCategorie() => throw new NotImplementedException();

    // Exercice 10 : (Nom, Catégorie, Prix) triés par catégorie puis par nom de produit.  (Join)
    public List<ProduitDetailDto> ProduitsAvecCategorie() => throw new NotImplementedException();

    // Exercice 11 : produits dont le nom contient "mot" (sans tenir compte de la casse), triés par nom.  (Contains)
    //               Un mot vide ou blanc retourne une liste vide.
    public List<Produit> Rechercher(string mot) => throw new NotImplementedException();

    // Exercice 12 : pagination. Produits triés par nom ; page 1 = premiers "taillePage" éléments.  (Skip / Take)
    public PageResultat<Produit> ObtenirPage(int page, int taillePage) => throw new NotImplementedException();

    // Exercice 13 : produit le plus cher et produit le moins cher.  (MaxBy / MinBy)
    public (Produit? PlusCher, Produit? MoinsCher) ExtremesDePrix() => throw new NotImplementedException();
}
