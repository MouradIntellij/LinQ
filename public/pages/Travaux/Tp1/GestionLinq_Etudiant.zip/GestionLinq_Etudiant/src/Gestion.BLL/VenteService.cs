using Gestion.DAL.Interfaces;
using Gestion.Entities;

namespace Gestion.BLL;

/// <summary>TP ÉTUDIANT - LINQ sur plusieurs sources : commandes + produits + clients.</summary>
public class VenteService
{
    private readonly ICommandeDal _commandeDal;
    private readonly IProduitDal _produitDal;
    private readonly IClientDal _clientDal;

    public VenteService(ICommandeDal commandeDal, IProduitDal produitDal, IClientDal clientDal)
    {
        _commandeDal = commandeDal;
        _produitDal = produitDal;
        _clientDal = clientDal;
    }

    // Exercice 14 : chiffre d'affaires par client = somme (Quantite * Prix), du plus grand au plus petit.
    //               (Join + GroupBy + Sum)
    public List<ClientCaDto> ChiffreAffairesParClient() => throw new NotImplementedException();

    // Exercice 14 (suite) : les "combien" meilleurs clients.  (Take)
    public List<ClientCaDto> MeilleursClients(int combien) => throw new NotImplementedException();

    // Bonus : villes des clients, sans doublon, triées.  (Select + Distinct + OrderBy)
    public List<string> VillesDesClients() => throw new NotImplementedException();
}
