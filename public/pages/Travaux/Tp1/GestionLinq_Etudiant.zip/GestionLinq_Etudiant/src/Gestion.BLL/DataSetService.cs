using System.Data;
using Gestion.DAL.Interfaces;

namespace Gestion.BLL;

/// <summary>TP ÉTUDIANT - LINQ to DataSet : on interroge un DataTable (mode déconnecté).</summary>
public class DataSetService
{
    private readonly IProduitDal _produitDal;

    public DataSetService(IProduitDal produitDal) => _produitDal = produitDal;

    // Exercice 15 : (Nom, Prix) des produits dont le prix > seuil, du plus cher au moins cher.
    //               Indice : _produitDal.GetAllAsTable().AsEnumerable() et row.Field<T>("Colonne")
    public List<(string Nom, decimal Prix)> ProduitsChersDepuisTable(decimal seuil) => throw new NotImplementedException();

    // Bonus : les produits dont Stock > 0, retournés sous forme de DataTable.
    //         Attention : CopyToDataTable() échoue si aucune ligne !
    public DataTable ProduitsEnStockCommeTable() => throw new NotImplementedException();
}
