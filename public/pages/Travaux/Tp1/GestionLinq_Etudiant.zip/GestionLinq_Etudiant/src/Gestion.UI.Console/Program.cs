using System.Globalization;
using System.Text;
using Gestion.BLL;
using Gestion.DAL.Interfaces;
using Gestion.DAL.Memory;
using Gestion.DAL.Sql;
#if SQLSERVER
using Microsoft.Data.SqlClient;
#endif

// =====================================================================
//  COUCHE UI (présentation) : elle ne parle qu'à la BLL.
//  Ici on construit aussi les objets (injection de dépendances "à la main").
// =====================================================================

Console.OutputEncoding = Encoding.UTF8;
CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

// Arguments facultatifs : --memory | --sql | --all
bool modeAuto = args.Contains("--all");
bool? utiliseSql = args.Contains("--sql") ? true : args.Contains("--memory") ? false : null;

Console.WriteLine("=== TP LINQ - Architecture multi-tiers (.NET 8) ===");
if (utiliseSql is null)
{
    Console.WriteLine("Source de données : 1) Mémoire (sans SQL Server)   2) SQL Server");
    Console.Write("Votre choix : ");
    utiliseSql = Console.ReadLine()?.Trim() == "2";
}

// ----- Composition : on choisit les implémentations de la DAL -----
IProduitDal produitDal; ICategorieDal categorieDal; IClientDal clientDal; ICommandeDal commandeDal;

if (utiliseSql == true)
{
#if SQLSERVER
    string cs = Environment.GetEnvironmentVariable("GESTION_CS")
        ?? @"Server=(localdb)\MSSQLLocalDB;Database=GestionLinqDb;Trusted_Connection=True;TrustServerCertificate=True";
    var db = new DbConnectionFactory(SqlClientFactory.Instance, cs);
    produitDal = new SqlProduitDal(db);
    categorieDal = new SqlCategorieDal(db);
    clientDal = new SqlClientDal(db);
    commandeDal = new SqlCommandeDal(db);
    Console.WriteLine("-> Mode SQL Server");
#else
    Console.WriteLine("Ce build ne contient pas le mode SQL Server (UseSqlServer=false). Mode Mémoire utilisé.");
    var store = new MemoryStore();
    produitDal = new MemoryProduitDal(store); categorieDal = new MemoryCategorieDal(store);
    clientDal = new MemoryClientDal(store); commandeDal = new MemoryCommandeDal(store);
#endif
}
else
{
    var store = new MemoryStore();
    produitDal = new MemoryProduitDal(store);
    categorieDal = new MemoryCategorieDal(store);
    clientDal = new MemoryClientDal(store);
    commandeDal = new MemoryCommandeDal(store);
    Console.WriteLine("-> Mode Mémoire");
}

// ----- Services de la BLL -----
var catalogue = new CatalogueService(produitDal, categorieDal);
var ventes = new VenteService(commandeDal, produitDal, clientDal);
var dataSet = new DataSetService(produitDal);

// ----- Les 15 exercices -----
var exercices = new SortedDictionary<int, (string Titre, Action Run)>
{
    [1]  = ("Where : produits en stock", () => Afficher(catalogue.ProduitsEnStock())),
    [2]  = ("Where + OrderByDescending : prix > 100", () => Afficher(catalogue.ProduitsPlusChersQue(100m))),
    [3]  = ("Select : noms en majuscules", () => Afficher(catalogue.NomsEnMajuscules())),
    [4]  = ("Select vers DTO : prix TTC (20 %)", () => Afficher(catalogue.ProduitsAvecPrixTtc().Take(5))),
    [5]  = ("FirstOrDefault : produit n°4 et n°99", () =>
    {
        Console.WriteLine(catalogue.TrouverParId(4)?.ToString() ?? "(introuvable)");
        Console.WriteLine(catalogue.TrouverParId(99)?.ToString() ?? "(introuvable)");
    }),
    [6]  = ("Any / All", () =>
    {
        Console.WriteLine($"Existe une rupture de stock ? {catalogue.ExisteProduitEnRupture()}");
        Console.WriteLine($"Tous les prix sont > 0 ?      {catalogue.TousLesPrixSontPositifs()}");
    }),
    [7]  = ("Count / Sum / Average : statistiques", () => Console.WriteLine(catalogue.CalculerStatistiques())),
    [8]  = ("OrderBy + ThenByDescending", () => Afficher(catalogue.TrierParCategorieEtPrix())),
    [9]  = ("GroupBy : statistiques par catégorie", () => Afficher(catalogue.StatistiquesParCategorie())),
    [10] = ("Join : produits avec leur catégorie", () => Afficher(catalogue.ProduitsAvecCategorie())),
    [11] = ("Contains : recherche « de »", () => Afficher(catalogue.Rechercher("de"))),
    [12] = ("Skip / Take : page 2 (taille 4)", () =>
    {
        var page = catalogue.ObtenirPage(2, 4);
        Console.WriteLine($"Page {page.Page}/{page.TotalPages} - {page.TotalElements} produits");
        Afficher(page.Elements);
    }),
    [13] = ("MaxBy / MinBy : prix extrêmes", () =>
    {
        var (plusCher, moinsCher) = catalogue.ExtremesDePrix();
        Console.WriteLine($"Plus cher  : {plusCher}");
        Console.WriteLine($"Moins cher : {moinsCher}");
    }),
    [14] = ("Join + GroupBy + Sum : CA par client", () =>
    {
        Afficher(ventes.ChiffreAffairesParClient());
        Console.WriteLine("-- Top 3 --");
        Afficher(ventes.MeilleursClients(3));
        Console.WriteLine("-- Bonus Distinct : villes --");
        Console.WriteLine(string.Join(", ", ventes.VillesDesClients()));
    }),
    [15] = ("LINQ to DataSet : AsEnumerable()", () =>
    {
        foreach (var (nom, prix) in dataSet.ProduitsChersDepuisTable(100m))
            Console.WriteLine($"  {nom,-25} {prix,9:F2} $");
        Console.WriteLine($"Produits en stock (DataTable) : {dataSet.ProduitsEnStockCommeTable().Rows.Count} lignes");
    }),
};

if (modeAuto)
{
    foreach (var (num, ex) in exercices) Executer(num, ex);
    return;
}

while (true)
{
    Console.WriteLine();
    foreach (var (num, ex) in exercices) Console.WriteLine($" {num,2}. {ex.Titre}");
    Console.WriteLine("  A. Tout exécuter      0. Quitter");
    Console.Write("Exercice : ");
    string? saisie = Console.ReadLine()?.Trim();

    if (saisie == "0") break;
    if (saisie?.ToUpper() == "A") { foreach (var (n, e) in exercices) Executer(n, e); continue; }
    if (int.TryParse(saisie, out int choix) && exercices.TryGetValue(choix, out var exo)) Executer(choix, exo);
    else Console.WriteLine("Choix invalide.");
}

// ----- Méthodes utilitaires d'affichage -----
static void Executer(int numero, (string Titre, Action Run) exo)
{
    Console.WriteLine();
    Console.WriteLine($"--- Exercice {numero} : {exo.Titre} ---");
    try
    {
        exo.Run();
    }
    catch (NotImplementedException)
    {
        Console.WriteLine("  (à compléter : méthode non implémentée dans la BLL)");
    }
}

static void Afficher<T>(IEnumerable<T> elements)
{
    foreach (var e in elements) Console.WriteLine("  " + e);
}
