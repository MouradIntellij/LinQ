namespace Gestion.Entities;

/// <summary>Une catégorie de produits (table Categorie).</summary>
public class Categorie
{
    public int Id { get; set; }
    public string Nom { get; set; } = string.Empty;

    public override string ToString() => $"{Id} - {Nom}";
}
