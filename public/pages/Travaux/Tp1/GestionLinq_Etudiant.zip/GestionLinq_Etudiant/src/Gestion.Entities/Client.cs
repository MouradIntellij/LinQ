namespace Gestion.Entities;

/// <summary>Un client (table Client).</summary>
public class Client
{
    public int Id { get; set; }
    public string Nom { get; set; } = string.Empty;
    public string Ville { get; set; } = string.Empty;

    public override string ToString() => $"#{Id} {Nom} ({Ville})";
}
