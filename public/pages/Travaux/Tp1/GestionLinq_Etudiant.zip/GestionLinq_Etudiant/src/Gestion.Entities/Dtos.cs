namespace Gestion.Entities;

// Les DTO (Data Transfer Objects) sont des objets "légers" créés par LINQ (Select)
// pour transporter uniquement les données dont l'interface a besoin.
// On utilise des "record" : syntaxe courte, immuables, ToString() automatique.

public record ProduitTtcDto(string Nom, decimal PrixHt, decimal PrixTtc);

public record ProduitDetailDto(string Nom, string Categorie, decimal Prix);

public record CategorieStatDto(string Categorie, int NombreProduits, decimal PrixMoyen);

public record ClientCaDto(string Client, decimal ChiffreAffaires);

public record StatistiquesStock(int NombreProduits, int NombreEnStock, decimal ValeurStock, decimal PrixMoyen);

public record PageResultat<T>(IReadOnlyList<T> Elements, int Page, int TaillePage, int TotalElements)
{
    public int TotalPages => TaillePage <= 0 ? 0 : (int)Math.Ceiling(TotalElements / (double)TaillePage);
}
