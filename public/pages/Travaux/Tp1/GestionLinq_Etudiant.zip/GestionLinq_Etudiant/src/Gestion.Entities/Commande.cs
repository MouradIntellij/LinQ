namespace Gestion.Entities;

/// <summary>Une commande : un client achète une quantité d'un produit (table Commande).</summary>
public class Commande
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public int ProduitId { get; set; }
    public int Quantite { get; set; }
    public DateTime DateCommande { get; set; }

    public override string ToString() => $"Cmd #{Id} client={ClientId} produit={ProduitId} qte={Quantite} le {DateCommande:yyyy-MM-dd}";
}
