namespace Gestion.Entities;

/// <summary>Un produit du catalogue (table Produit).</summary>
public class Produit
{
    public int Id { get; set; }
    public string Nom { get; set; } = string.Empty;
    public decimal Prix { get; set; }
    public int Stock { get; set; }
    public int CategorieId { get; set; }

    public override string ToString() => $"#{Id,-2} {Nom,-28} {Prix,9:F2} $  stock={Stock,3}  cat={CategorieId}";
}
